function mean_diff = computeMeanDifference(df_test_table,y_pred, sensitive_attribute)
    % y_pred: 预测的二进制标签向量 (0 或 1)
    % sensitive_attribute: 敏感特征向量 (2 或 1)

    % 计算 E[ ˆY |S = 1]，即在 S = 1 时的预测结果期望
    mean_pred_s1 = mean(y_pred(df_test_table(:, sensitive_attribute) == 1));
    
    % 计算 E[ ˆY |S = 0]，即在 S = 0 时的预测结果期望
    mean_pred_s0 = mean(y_pred(df_test_table(:, sensitive_attribute) == 2));
    
    % 计算 Mean difference
    mean_diff = abs(mean_pred_s1 - mean_pred_s0);
end

