function oae = computeOverallAccuracyEquality(df_test_table,y_true, y_pred, sensitive_attribute)
    % y_true: 真实的标签向量 (0 或 1)
    % y_pred: 预测的二进制标签向量 (0 或 1)
    % sensitive_attribute: 敏感属性向量 (2 或 1)
    
    idx_sensitive = (df_test_table(:, sensitive_attribute) == 1);
    idx_unprotected = (df_test_table(:, sensitive_attribute) == 2);
    
    accuracy_sensitive = sum(y_true(idx_sensitive) == y_pred(idx_sensitive)) / sum(idx_sensitive);
    accuracy_unprotected = sum(y_true(idx_unprotected) == y_pred(idx_unprotected)) / sum(idx_unprotected);
    
    oae = abs(accuracy_sensitive - accuracy_unprotected);
end

