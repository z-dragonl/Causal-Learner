function pe = computePredictiveEquality(df_test_table,y_true, y_pred, sensitive_attribute)
    % y_true: 真实的标签向量 (0 或 1)
    % y_pred: 预测的二进制标签向量 (0 或 1)
    % sensitive_attribute: 敏感属性向量 (2 或 1)
    
    idx_sensitive = (df_test_table(:, sensitive_attribute) == 1);
    idx_unprotected = (df_test_table(:, sensitive_attribute) == 2);
    
    p_y0_s1_pred1 = sum(y_true(idx_sensitive) == 0 & y_pred(idx_sensitive) == 1) / sum(y_true(idx_sensitive) == 0);
    p_y0_s0_pred1 = sum(y_true(idx_unprotected) == 0 & y_pred(idx_unprotected) == 1) / sum(y_true(idx_unprotected) == 0);
    
    pe = abs(p_y0_s1_pred1 - p_y0_s0_pred1);
end

