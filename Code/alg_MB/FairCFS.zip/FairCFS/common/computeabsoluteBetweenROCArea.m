function abra = computeabsoluteBetweenROCArea(df_test_table,y_true, y_pred, sensitive_attribute)
    % y_true: 真实的标签向量 (0 或 1)
    % y_pred: 预测的正类别概率向量
    % sensitive_attribute: 敏感属性向量 (0 或 1)
    %0-1
    idx_sensitive = (df_test_table(:, sensitive_attribute) == 1);
    idx_unprotected = (df_test_table(:, sensitive_attribute) == 2);
    
    [tpr_sensitive, fpr_sensitive] = computeROCCurve(y_true(idx_sensitive), y_pred(idx_sensitive));
    [tpr_unprotected, fpr_unprotected] = computeROCCurve(y_true(idx_unprotected), y_pred(idx_unprotected));
    
    abra = abs(trapz(fpr_sensitive, tpr_sensitive) - trapz(fpr_unprotected, tpr_unprotected));
end

function [tpr, fpr] = computeROCCurve(y_true, y_pred)
    [~, order] = sort(y_pred, 'descend');
    sorted_labels = y_true(order);
    
    tpr = cumsum(sorted_labels) / sum(y_true);
    fpr = cumsum(~sorted_labels) / sum(~y_true);
end