function [ selected_X,MBS,test,time,sepset ] = MBFair( data,label,sensitive, alpha,maxK)
%FEATURELIST 此处显示有关此函数的摘要
%   此处显示详细说明

    train_data=[data,label];
    train_data = double(train_data);

    [row_num, col_num] = size(train_data);
    ns=max(train_data+1);

    if (nargin == 5)
        ns=max(train_data);
        [~,p]=size(train_data);
        maxK=3;
    end

    start=tic;

    [pcY,ntestY,ntimeY] =  CFS_GetPCD_G2(train_data,col_num,alpha,ns,p,maxK);
    MBY=pcY;
    disp(MBY);

    if ismember(sensitive,MBY)
        %MBY(sensitive) = [];
        MBY = mysetdiff(MBY,sensitive);
    end
    X=MBY;
    [pcS,ntestS,ntimeS] =  CFS_GetPCD_G2(train_data,sensitive,alpha,ns,p,maxK);
    MBS=pcS;


    sepset=cell(1,p);
    test=0;
    
    selected_X=[];
    selected_C1=[];
    selected_C2=[];
    
    U = setdiff(MBY, MBS);
    
    score=1000000;
    tmp_pval=ones(1,p)*score;
    dep=zeros(1,score);
    M1 = [];
    %M1    
    for i=1:length(U)
            C = U(i);
            cutSetSize = 0;
            break_flag=0;  
            S = MBS;
            while length(S) >= cutSetSize&&cutSetSize<=maxK
                SS = subsets1(S, cutSetSize);   
            
                for si=1:length(SS)
                    Z = SS{si};
                    test=test+1;
                   
                    [tmp_pval(C),dep(1)]=my_g2_test(C,sensitive,S,train_data,ns,alpha);
                    if isnan(tmp_pval(C))
                        CI=0;
                    else
                        if tmp_pval(C)<=alpha%依赖
                            CI=0;
                        else%独立
                            CI=1;
                        end
                    end
                
                    if CI==1
                        sepset{C}=Z;
                        %U = mysetdiff(U,C);
                        break_flag=1;
                        M1 = [M1 C];
                        break;
                    end
                
                end
                if break_flag
                   break;
                end
            
                cutSetSize = cutSetSize + 1;
            end
    end
    selected_C1=M1;

    
     %M2
     temp_X = setdiff(MBY,selected_C1);
     %ZC2=[MBS selected_C1];
     ZC2 = [];
     for i=1:length(temp_X)
            C = temp_X(i);
            cutSetSize = 0;
            break_flag=0;
            
            %while length(ZC2) >= cutSetSize&&cutSetSize<=maxK
                %SS = subsets1(ZC2, cutSetSize);   
            
                %for si=1:length(SS)
                    %Z = SS{si};
                    test=test+1;
                    [tmp_pval(C),dep(si)]=my_g2_test(C,sensitive,[],train_data,ns,alpha);
                    if isnan(tmp_pval(C))
                        CI=1;
                    else
                        if tmp_pval(C)<=alpha%依赖
                            CI=0;
                        else%独立
                            CI=1;
                        end
                    end
                
                    if CI==1
                        sepset{C}=Z;
                        %U = mysetdiff(U,C);
                        selected_C2=[selected_C2 C];
                        %break_flag=1;
                        %break;
                    end
                
                %end
                %if break_flag
                  %  break;
                %end
            
                %cutSetSize = cutSetSize + 1;
            %end
     end
    

     selected_X=[selected_C1 selected_C2];
     
     time=toc(start);
     disp(time);
     disp(['X: ', num2str(selected_X)]);
end
    


