function cmi = computeConditionalMutualInformation(df_test_table,y_pred, sensitive_attribute, mb_features)
    % y_pred: 预测的二进制标签向量 (0 或 1)
    % sensitive_attribute: 敏感特征向量 (0 或 1)
    % mb_features: 给定的特征下标集合
    % df_test_table: 包含测试数据的表格
    
    % 使用 mb_features 获取对应的测试数据
    mb_data = df_test_table(:, mb_features);
    
    % 计算在给定 MB(S) 的条件下，S 与 Y 之间的条件互信息
    cmi = conditionalMutualInformation(df_test_table(:, sensitive_attribute), y_pred, mb_data);
end


function cmi = conditionalMutualInformation(X, Y, Z)
    % 计算在给定 Z 的条件下，X 与 Y 之间的条件互信息
    p_xyz = jointProbability(X, Y, Z);
    p_z = sum(p_xyz, 3);
    
    cmi = sum(sum(sum(p_xyz .* log2(p_xyz ./ (p_z * p_z')))));
end

function p = jointProbability(X, Y, Z)
    % 计算联合概率分布
    if nargin == 2
        p = accumarray([X Y]+1, 1) / numel(X);
    elseif nargin == 3
        p = accumarray([X Y Z]+1, 1) / numel(X);
    end
end
