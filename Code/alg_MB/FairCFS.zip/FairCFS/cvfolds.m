function [A] = cvfolds(data_label,sensitive, alpha,maxK,dataset)
    rand('state',6);
    %CVFOLDS 此处显示有关此函数的摘要
    %   此处显示详细说明
    % 假设 X 是原始数据集，y 是对应的标签
    features = data_label.features;
    labels = data_label.labels;
  for classi = 2:4  
    % 设置十折交叉验证的参数
    numFolds = 10;
    
    [data_r, data_c] = size(features);
    indices = crossvalind('Kfold', data_r, 10);

    % 初始化用于存储实验结果的数组
    accuracyResults = zeros(numFolds, 1);
    precisionResults = zeros(numFolds, 1);
    recallResults = zeros(numFolds, 1);
    f1_scoreResults = zeros(numFolds, 1);
    spd_values = zeros(numFolds, 1);
    pe_values = zeros(numFolds, 1);

    % 进行十折交叉验证
    for fold = 1:numFolds
        % 获取训练集和测试集的索引
        testIdx = (indices == fold);
        trainIdx = ~testIdx;

        % 根据索引获取训练集和测试集数据
        X_train = features(trainIdx, :);
        y_train = labels(trainIdx);
        X_test = features(testIdx, :);
        y_test = labels(testIdx);
        
        % 在训练集上进行特征选择（假设这里用相关系数法）
        [selected_features ,MBS,test,time,sepset] = MBFair(X_train, y_train,sensitive, alpha,maxK);
        A=selected_features;
        X_train_selected = X_train(:, selected_features);
        X_test_selected = X_test(:, selected_features);
        
        % 训练逻辑回归分类器
        X_train_selected = double(X_train_selected);
        y_train = double(y_train);
        y_train_binary = (y_train == 2); % 将 2 转换为 1，将 1 转换为 0
        if classi ==1
            model = fitcsvm(X_train_selected, y_train_binary);
        elseif classi==2
            model = fitcnb(X_train_selected, y_train_binary);
        elseif classi==3
            model = fitcknn(X_train_selected, y_train_binary);
        elseif classi==4
            model = fitglm(X_train_selected, y_train_binary, 'Distribution', 'binomial');
        end
        % 使用训练好的分类器进行预测
        X_test_selected = double(X_test_selected);
        y_test = double(y_test);    
        y_test_binary= (y_test == 2);
        y_test_binary= double(y_test_binary);
    
        y_pred = predict(model, X_test_selected);
        y_pred_nobinay=y_pred;
        y_pred = y_pred >= 0.5;% 将预测结果转换为二进制标签（0 或 1）
        y_pred = double(y_pred);

        

        % 计算混淆矩阵
        confusion_matrix = confusionmat(y_test_binary, y_pred);
        
        TP = confusion_matrix(1,1);% 真正例
        TN = confusion_matrix(2,2);% 真反例
        FP = confusion_matrix(2,1);% 假正例
        FN = confusion_matrix(1,2);% 假反例

        accuracy = (TP + TN) / (TP + TN + FP + FN);
        accuracyResults(fold) = accuracy;
        precision = TP / (TP + FP);
        recall = TP / (TP + FN);
        f1_score = 2 * (precision * recall) / (precision + recall);


        precisionResults(fold) = precision;
        recallResults(fold) = recall;
        f1_scoreResults(fold) = f1_score;
        % 显示结果
        disp(fold);
        disp(['准确率: ', num2str(accuracy)]);
        disp(['精确率: ', num2str(precision)]);
        disp(['召回率: ', num2str(recall)]);
        disp(['F1分数: ', num2str(f1_score)]); 
        
        %计算公平指标
        df_test_table = X_test;
        %df_test_label=  y_test;
        %SPD
        spd = computestatisticalParityDifference(df_test_table,y_pred, sensitive);
        spd_values(fold) = spd;

        % 计算
        pe=computePredictiveEquality(df_test_table,y_test_binary,y_pred, sensitive);
        pe_values(fold) = pe;
    end

    % 计算平均实验结果
    averageAccuracy = mean(accuracyResults);
    averageprecision = mean(precisionResults);
    averagerecall = mean(recallResults);
    averagef1_score = mean(f1_scoreResults);
    average_spd = mean(spd_values);
    average_pe = mean(pe_values);

    % 将结果保存到txt文件
    if classi ==1
            outputFile = fopen('resultsSvmOur8.txt', 'a');
            fprintf(outputFile, 'datasets：%s\n', dataset);
    elseif classi==2
            outputFile = fopen('resultsNBOur9.txt', 'a');
            fprintf(outputFile, 'datasets：%s\n', dataset);
    elseif classi==3
            outputFile = fopen('resultsKnnOur9.txt', 'a');
            fprintf(outputFile, 'datasets：%s\n', dataset);
    elseif classi==4
            outputFile = fopen('resultsLgrOur9.txt', 'a');
            fprintf(outputFile, 'datasets：%s\n', dataset);
    end
    
    fprintf(outputFile, '平均准确率：%f\n', averageAccuracy);
    fprintf(outputFile, '平均精确率：%f\n', averageprecision);
    fprintf(outputFile, '平均召回率：%f\n', averagerecall);
    fprintf(outputFile, '平均F1分数：%f\n', averagef1_score);
    fprintf(outputFile, '平均SPD：%f\n', average_spd);
    fprintf(outputFile, '平均pe：%f\n', average_pe);
    
    fclose(outputFile);
    
    A=fold;
  end
end