function spd = computestatisticalParityDifference(df_test_table, y_pred, sensitive_attribute)
    % y_pred: 预测的类别概率向量
    % sensitive_attribute: 敏感属性向量 (0 或 1)0<spd<1

    prob_protected = mean(y_pred(df_test_table(:, sensitive_attribute) == 1, :));
    prob_unprotected = mean(y_pred(df_test_table(:, sensitive_attribute) == 2, :));
    spd = abs(prob_protected - prob_unprotected);
end

