%FairCFS code;
%The dataset format is shown in German. Note: All discrete attribute
%values start from 1;
%run main.m
%output: A=the selected feature set;
addpath(genpath('common'));
addpath(genpath('data'));
addpath(genpath('MBforFair'));
addpath(genpath('MB'));
clc;
clear;

        
alpha = 0.01;
maxK=3  ;

for loop_i= 2:2

        if loop_i==1
            continue;
        elseif loop_i==2
            dataset='German';
            train_path_file='.\data\German\german_processed_data.mat';
            sensitive=13;%age
            disp('german')       
        elseif loop_i==3
            dataset='compas';
            train_path_file='.\data\Compas\compas_clean.mat';
            sensitive=1;%sex
            disp('compas')
        elseif loop_i==4
            continue;
        elseif loop_i==5
            dataset='CreditCardClients';
            train_path_file='.\data\CreditCardClients\creditcardclients.mat';
            sensitive=2;%sex
            disp('CreditCardClients')  
        elseif loop_i==6
            dataset='Lawschool';
            train_path_file='.\data\Lawschool\law_school.mat';
            sensitive=9;%sex
            disp('Lawschool')
        elseif loop_i==7
            dataset='oulad';
            train_path_file='.\data\oulad\oulad.mat';
            sensitive=3;%sex
            disp('oulad')
        elseif loop_i==8
            dataset='Studentperformance';
            train_path_file='.\data\Studentperformance\student_mat.mat';
            sensitive=2;%sex
            disp('student_mat')
        elseif loop_i==9
            dataset='Studentperformance';
            train_path_file='.\data\Studentperformance\student_por.mat';
            sensitive=2;%sex
            disp('student_por')
       
        end
        data_label=load(train_path_file);
        [A]=cvfolds(data_label,sensitive,alpha,maxK,dataset);
        disp(['main_loop_i: ',num2str(loop_i)]);
        
  

end
    
    




