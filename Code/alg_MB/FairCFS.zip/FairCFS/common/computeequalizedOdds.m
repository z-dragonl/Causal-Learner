function eo = computeequalizedOdds(df_test_table,y_true, y_pred, sensitive_attribute)
    % y_true: 真实的标签向量 (0 或 1)
    % y_pred: 预测的二进制标签向量 (0 或 1)
    % sensitive_attribute: 敏感属性变量
    %0-2
    idx_sensitive = (df_test_table(:, sensitive_attribute) == 1);
    idx_unprotected = (df_test_table(:, sensitive_attribute) == 2);
    
    % 在正类别上计算误分类率
    error_positive_sensitive = mean(y_true(idx_sensitive) ~= y_pred(idx_sensitive));
    error_positive_unprotected = mean(y_true(idx_unprotected) ~= y_pred(idx_unprotected));
    
    % 在负类别上计算误分类率
    error_negative_sensitive = mean((1 - y_true(idx_sensitive)) ~= y_pred(idx_sensitive));
    error_negative_unprotected = mean((1 - y_true(idx_unprotected)) ~= y_pred(idx_unprotected));
    
    % 计算 Equalized Odds
    eo = abs(error_positive_sensitive - error_positive_unprotected) + abs(error_negative_sensitive - error_negative_unprotected);
end